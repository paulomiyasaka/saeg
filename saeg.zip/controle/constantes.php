﻿<?php

//CONEXÃO COM BANCO DE DADOS
define('HOST', "localhost");
define('USER', "root");
define('PASS', "");
define('DATABASE', "saegnew");
define('SERVER', "mysql:dbname=".DATABASE.";host=".HOST);

//DIRETÓRIOS
define('DIR_CLASSES', 'controle/');


//TABELAS DO BANCO DE DADOS
define('TB_UNIDADES', 'unidades');


?>